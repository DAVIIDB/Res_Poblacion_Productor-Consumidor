﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poblacion_ProductorConsumidor
{
    public class  Diccionario 
    {
        //public Dictionary<string, int> aux = new Dictionary<string, int>();

        public String clave { get; set; }

        public double valor { get; set; }



    }
}
