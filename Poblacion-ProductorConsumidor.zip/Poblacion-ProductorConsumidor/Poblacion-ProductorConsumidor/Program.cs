﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///Empiezo poniendo las librerias faltantes correspondientes
using System.Collections.Concurrent;

using System.IO;


namespace Poblacion_ProductorConsumidor
{
    class Program
    {
        static void Main(string[] args)
        {
            ///ACA HAGO QUE SE LOCALIZE EL ARCHIVO ORIGEN DE DATOS Y SE ALMACENE EN UN STRING
            String origen = AppDomain.CurrentDomain.BaseDirectory + @"/../../../Partidos.txt";

            int capacidad = 10000; //capacidad maxima de la blockingcolection

            BlockingCollection<string> bc = new BlockingCollection<string>(capacidad);

            var tf = new TaskFactory(TaskCreationOptions.LongRunning, TaskContinuationOptions.None);

            Task productor = tf.StartNew(() =>
            {// aca inician los productores

                foreach (string rec in File.ReadLines(origen))// recorro linea por linea del nuevo string de lineas de origen 

                    //añado cada linea de archivo a la blockingcolection
                   
                    bc.Add(rec);
                bc.CompleteAdding();/// señal cuando no haya mas datos que cargar en la blockingcolection y poder proseguir 




            });


            //int nucleos = 4;// nro de nucleos 


            // Task<Dictionary<String, double>>[] consumidor = new Task<Dictionary<string, double>>[nucleos];


            // for (int i = 0; i < nucleos; i++)
            // {
            // A continuacion creo una tarea llamada consumidor usando la fabrica de tareas "tf" que retorne un diccionario(local1) de tipo correspondiente
            Task<Dictionary<String,double>> consumidor = tf.StartNew<Dictionary<String, double>>(() =>
                {


                    Dictionary<String, double> local1 = new Dictionary<String, double>();

                    //   Dictionary<String, long> local2 = new Dictionary<String, long>();


                    while (!bc.IsCompleted)// si bc no esta completado al extraer los datos seguir
                    {



                        String line = bc.Take();// toma una linea de bc 
                        Diccionario d = parse(line); // cree un una nueva instancia Diccionario para almacernar los datos necesarios con este metodo
                        
                        if (!local1.ContainsKey(d.clave))// si local1 no contiene esta clave la agrega 
                            local1.Add(d.clave, d.valor);

                        else
                            
                        
                        local1[d.clave] += d.valor; //sino suma a la clave el valor correspondiente y sigue
                        
                        


                    }







                    /*
                    foreach (string r in local1.Keys )
                    {
                        if (!local1.ContainsKey(r))

                            local1.Add(r, 0);
                        else

                        {
                            long valor = local1[r];
                            local1[r] += valor;
                        }


                    }
                    */

                    return local1;
                });
                
            
            //consumidor.Start();
            
            
               // Task.WaitAll(consumidor[0], consumidor[1], consumidor[2], consumidor[3]);
            
           


                Dictionary<String, double> total = new Dictionary<String, double>();
                
                total = consumidor.Result;// toma cada resultado y lo almacena en total 
            //}
            Dictionary<String, double> general = new Dictionary<String, double>();
            foreach (var p in total.Keys)// recorre cada clave y almacena cada valor para luego añadirselo a general con su correspondiente par clave
            {
                double t = total[p];
               
                if (!general.ContainsKey(p))
                    general.Add(p, t);
                else
                    total[p] = +t;// si ya contiene la clave suma a esta el valor siguiente de la misma otra clave
            }
            var top5 = general.OrderByDescending(x => x.Value).Take(5); //aca se procesa los resultados finales del diccionario general

                Console.WriteLine();

                Console.WriteLine("Resultados:");
                foreach (var partido in top5)

                    Console.WriteLine("{0}:{1}", partido.Key, partido.Value);


            
                try
                {


                    productor.Wait();

                }
                catch (AggregateException ae)
                {
                    ae = ae.Flatten();
                    foreach (Exception e in ae.InnerExceptions)
                        Console.WriteLine("NOTE: unexpected error from producer: '{0}'.", e.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("NOTE: unexpected error from producer: '{0}'.", ex.Message);
                }

                Console.WriteLine("Presione Enter para finalizar");
                Console.ReadLine();
            }

        



























        private static Diccionario parse (String linea) {
           // char[] separador = { ';' };

            String[] tomar = linea.Split(';');

            //if (tomar.Length !=2)
            //{
              //  return null;
            //}
            String partido = tomar[0];

            String localidad = tomar[1];

            double poblacion;

            if (double.TryParse(tomar[2], out poblacion) == false)
                return null;
            
                
            //Dictionary<String, int> col = new Dictionary<String, int>();

            //Dictionary<string, long> localidades = new Dictionary<string, long>();


            Diccionario d = new Diccionario();
            d.clave = partido;
            d.valor = poblacion;

            return d ;




        }

        




    }
}
